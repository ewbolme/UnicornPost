import json
import psycopg2
import os
import boto3

def get_secret(secret_name):
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager'
    )

    # Retrieve the secret value
    response = client.get_secret_value(SecretId=secret_name)

    if 'SecretString' in response:
        secret = json.loads(response['SecretString'])
        print("secret",secret)
        return secret
    else:
        raise ValueError("Secrets Manager response doesn't contain SecretString")

def get_rds_endpoint(db_instance_identifier):
    client = boto3.client('rds')

    try:
        response = client.describe_db_instances(DBInstanceIdentifier=db_instance_identifier)

        if 'DBInstances' in response and len(response['DBInstances']) > 0:
            return response['DBInstances'][0]['Endpoint']['Address']
        else:
            return None
    except Exception as e:
        print(f"Error retrieving RDS endpoint: {str(e)}")
        return None
    
def lambda_handler(event,context):
    # Retrieve environment variables
    rds_db="unicorn-db"
    db_port = 5432
    secret_manager_name= "dev/rds"

    db_host = get_rds_endpoint(rds_db)
    # Retrieve database user and password from Secrets Manager
    secrets = get_secret(secret_manager_name)  # Replace with your Secrets Manager secret name
    db_user = secrets['username']
    db_password = secrets['password']
    db_name = "postgres" #secrets['dbname']

    commands = (
        """
        CREATE TABLE public.users (
        cognito_user_id varchar(50) NOT NULL,
        user_name varchar(50) NULL,
        user_email varchar(50) NULL,
        created_at timestamp NULL,
        is_active bool NULL,
        user_id bigserial NOT NULL,
        is_reset bool NULL DEFAULT false,
        reset_password_count varchar NULL DEFAULT 0,
        CONSTRAINT users_pkey PRIMARY KEY (cognito_user_id),
        CONSTRAINT users_un UNIQUE (user_email)
        );
        """
    )

    conn = None
    try:
        # connect to the PostgreSQL server
        conn = psycopg2.connect(
            user=db_user,
            password=db_password,
            host=db_host,
            port=db_port,
            database=db_name,
            sslmode='require'
        )
        cur = conn.cursor()
        cur.execute(commands)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        conn.commit()
        return {
            'statusCode': 200,
            'body': 'Tables created successfully!'
        }
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        return {
            'statusCode': 404,
            'body': 'Tables not created!'
        }
    finally:
        if conn is not None:
            conn.close()



