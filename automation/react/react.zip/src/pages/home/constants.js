
export const marks = [
    {
      value: 2,
      label: '2',
    },
    {
      value: 4,
      label: '4',
    },
    {
      value: 6,
      label: '6',
    },
    {
      value: 8,
      label: '8',
    },
    {
      value: 10,
      label: '10',
    },
];



export const genreList = [{
  name: "Non-Tech",
  value: "non tech"
}, {
  name: "Technology",
  value: "tech"
}, {
  name: "Crypto-Currency",
  value: "crypto currency"
},{
  name: "Cloud Provider News",
  value: "cloud provider news"
}];




